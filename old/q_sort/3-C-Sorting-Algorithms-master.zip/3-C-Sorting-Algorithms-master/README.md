3-C-Sorting-Algorithms
======================

Generic merge sort, quick sort and insertion sort algorithms written in C programming language.

I have included the file "demonstration.c" to demonstrate how to use the sorting algorithms and the files "gen_int.h"
and "gen_int.c" to demonstrate the functions needed for the sorting algorithms.
If you wish to sort a different type of array (doubles array for instance) please write your own "gen_double" library.