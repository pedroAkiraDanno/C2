A program written in C that outlines a 2-3 binary tree data structure. Includes a numerous amount of methods for modifying and creating the tree.
